
import 'package:flutter/material.dart';
import '../models/water_record.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final List<WaterRecord> records = [];

  final int dailyGoal = 2000;

  int get totalWater {
    return records.fold(0, (sum, record) => sum + record.amount);
  }

  double get progress {
    return (totalWater / dailyGoal).clamp(0.0, 1.0);
  }

  // MAIN DASHBOARD

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'HydroPulse',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.blue,
          ),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 16),
            child: Icon(
              Icons.water_drop,
              color: Colors.blue,
              size: 28,
            ),
          ),
        ],
      ),

      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

              const Text(
                'Daily Hydration',
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 8),

              const Text(
                'Keep track of your daily water intake.',
                style: TextStyle(color: Colors.grey),
              ),

              const SizedBox(height: 24),

              // HYDRATION PROGRESS

              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.blue,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [

                    const Text(
                      'TODAY\'S PROGRESS',
                      style: TextStyle(
                        color: Colors.white70,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    const SizedBox(height: 16),

                    Text(
                      '$totalWater ml',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 36,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    Text(
                      'of $dailyGoal ml daily goal',
                      style: const TextStyle(
                        color: Colors.white70,
                      ),
                    ),

                    const SizedBox(height: 20),

                    ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: LinearProgressIndicator(
                        value: progress,
                        minHeight: 12,
                        backgroundColor: Colors.white30,
                        valueColor:
                            const AlwaysStoppedAnimation<Color>(
                          Colors.white,
                        ),
                      ),
                    ),

                    const SizedBox(height: 12),

                    Text(
                      '${(progress * 100).toInt()}% completed',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 28),

              // CREATE BUTTON

              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton.icon(
                  onPressed: addWaterRecord,
                  icon: const Icon(Icons.add),
                  label: const Text(
                    'Add Water Intake',
                    style: TextStyle(fontSize: 16),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 28),

              const Text(
                'Water Intake History',
                style: TextStyle(
                  fontSize: 21,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 16),

              // READ: DISPLAY RECORDS

              if (records.isEmpty)
                const Center(
                  child: Padding(
                    padding: EdgeInsets.all(30),
                    child: Column(
                      children: [
                        Icon(
                          Icons.water_drop_outlined,
                          size: 50,
                          color: Colors.grey,
                        ),
                        SizedBox(height: 12),
                        Text(
                          'No water records yet.',
                          style: TextStyle(color: Colors.grey),
                        ),
                        Text(
                          'Add your first water intake!',
                          style: TextStyle(color: Colors.grey),
                        ),
                      ],
                    ),
                  ),
                )
              else
                ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: records.length,
                  itemBuilder: (context, index) {

                    final record = records[index];

                    return Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      child: ListTile(
                        leading: const CircleAvatar(
                          backgroundColor: Color(0xFFE3F2FD),
                          child: Icon(
                            Icons.water_drop,
                            color: Colors.blue,
                          ),
                        ),

                        title: Text(
                          record.description,
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                        ),

                        subtitle: Text(
                          '${record.amount} ml • '
                          '${record.dateTime.hour.toString().padLeft(2, '0')}:'
                          '${record.dateTime.minute.toString().padLeft(2, '0')}',
                        ),

                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [

                            // UPDATE BUTTON

                            IconButton(
                              icon: const Icon(
                                Icons.edit,
                                color: Colors.orange,
                              ),
                              onPressed: () {
                                editWaterRecord(index);
                              },
                            ),

                            // DELETE BUTTON

                            IconButton(
                              icon: const Icon(
                                Icons.delete,
                                color: Colors.red,
                              ),
                              onPressed: () {
                                deleteWaterRecord(index);
                              },
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }

  // ==========================================
  // CREATE: ADD A NEW WATER RECORD
  // ==========================================

  void addWaterRecord() {
    final amountController = TextEditingController();
    final descriptionController = TextEditingController();

    showDialog(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Add Water Intake'),

          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [

              TextField(
                controller: amountController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Water Amount (ml)',
                  hintText: 'Example: 250',
                  prefixIcon: Icon(Icons.water_drop),
                ),
              ),

              const SizedBox(height: 16),

              TextField(
                controller: descriptionController,
                decoration: const InputDecoration(
                  labelText: 'Description',
                  hintText: 'Example: Morning Water',
                  prefixIcon: Icon(Icons.edit_note),
                ),
              ),
            ],
          ),

          actions: [

            TextButton(
              onPressed: () {
                Navigator.pop(dialogContext);
              },
              child: const Text('Cancel'),
            ),

            ElevatedButton(
              onPressed: () {
                final amount = int.tryParse(
                  amountController.text.trim(),
                );

                final description =
                    descriptionController.text.trim();

                if (amount == null ||
                    amount <= 0 ||
                    description.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text(
                        'Enter a valid amount and description.',
                      ),
                    ),
                  );
                  return;
                }

                setState(() {
                  records.add(
                    WaterRecord(
                      amount: amount,
                      description: description,
                      dateTime: DateTime.now(),
                    ),
                  );
                });

                Navigator.pop(dialogContext);

                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Water record added successfully!'),
                  ),
                );
              },
              child: const Text('Add'),
            ),
          ],
        );
      },
    );
  }

  // ==========================================
  // UPDATE: EDIT AN EXISTING WATER RECORD
  // ==========================================

  void editWaterRecord(int index) {
    final record = records[index];

    final amountController = TextEditingController(
      text: record.amount.toString(),
    );

    final descriptionController = TextEditingController(
      text: record.description,
    );

    showDialog(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Edit Water Intake'),

          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [

              TextField(
                controller: amountController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Water Amount (ml)',
                  prefixIcon: Icon(Icons.water_drop),
                ),
              ),

              const SizedBox(height: 16),

              TextField(
                controller: descriptionController,
                decoration: const InputDecoration(
                  labelText: 'Description',
                  prefixIcon: Icon(Icons.edit_note),
                ),
              ),
            ],
          ),

          actions: [

            TextButton(
              onPressed: () {
                Navigator.pop(dialogContext);
              },
              child: const Text('Cancel'),
            ),

            ElevatedButton(
              onPressed: () {
                final amount = int.tryParse(
                  amountController.text.trim(),
                );

                final description =
                    descriptionController.text.trim();

                if (amount == null ||
                    amount <= 0 ||
                    description.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text(
                        'Enter a valid amount and description.',
                      ),
                    ),
                  );
                  return;
                }

                setState(() {
                  records[index].amount = amount;
                  records[index].description = description;
                });

                Navigator.pop(dialogContext);

                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Water record updated successfully!'),
                  ),
                );
              },
              child: const Text('Save Changes'),
            ),
          ],
        );
      },
    );
  }

  // ==========================================
  // DELETE: REMOVE A WATER RECORD
  // ==========================================

  void deleteWaterRecord(int index) {
    showDialog(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Delete Water Record'),

          content: const Text(
            'Are you sure you want to delete this water record?',
          ),

          actions: [

            TextButton(
              onPressed: () {
                Navigator.pop(dialogContext);
              },
              child: const Text('Cancel'),
            ),

            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
              ),

              onPressed: () {
                setState(() {
                  records.removeAt(index);
                });

                Navigator.pop(dialogContext);

                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Water record deleted successfully!'),
                  ),
                );
              },

              child: const Text('Delete'),
            ),
          ],
        );
      },
    );
  }
}
