
class WaterRecord {
  int amount;
  String description;
  DateTime dateTime;

  WaterRecord({
    required this.amount,
    required this.description,
    required this.dateTime,
  });
}
