package com.example.hydropulse_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
